local Test

Test = vape.Categories.Utility:CreateModule({
    Name = 'TestModule',
    Function = function(enabled) print(enabled..'!') end,
    Tooltip = 'just a lil\' test module :)'
})