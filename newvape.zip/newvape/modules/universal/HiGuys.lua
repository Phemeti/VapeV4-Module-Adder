local HiGuysIFeelVeryGayRN

HiGuysIFeelVeryGayRN = vape.Categories.Utility:CreateModule({
    Name = 'HiGuysIFeelVeryGayRN',
    Function = function()
        print('dude ur sooo gay ⚠️⚠️🏳️‍🌈🏳️‍🌈🏳️‍🌈🏳️‍🌈')
    end,
    Tooltip = 'bro what'
})